﻿namespace Microsoft
{
    internal class VisualStudio
    {
        internal class TestTools
        {
        }
    }
}